package com.example.tripou2.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ImageView;

import com.example.tripou2.Comentario;
import com.example.tripou2.LugarViewModel;
import com.example.tripou2.MenuPrincipalViewModel;
import com.example.tripou2.MyAdapter;
import com.example.tripou2.MyAdapterL;
import com.example.tripou2.PontoTuristico;
import com.example.tripou2.R;
import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;

import java.util.List;

public class Lugar extends AppCompatActivity {

    static int NEW_ITEM_REQUEST = 1;

    MyAdapterL myAdapterL;

    CarouselView carouselView;

    int[] sampleImages = {R.drawable.buda, R.drawable.china1, R.drawable.penha1};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lugar);

        carouselView = (CarouselView) findViewById(R.id.carouselView);
        carouselView.setPageCount(sampleImages.length);

        carouselView.setImageListener(imageListener);

        LugarViewModel viewModel = new ViewModelProvider(this).get(LugarViewModel.class);
        List<Comentario> comentarios = viewModel.getItensC();

        myAdapterL = new MyAdapterL(this, comentarios); //instância do MyAdapter

        //configurando RecyclerView:
        RecyclerView rvItens = findViewById(R.id.rvComentario);
        rvItens.setHasFixedSize(true); //diz que todos os itens da lista terão o mesmo tamanho

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);//diz de que forma os itens serão exibidos na lista, nesse cado, será de forma linear
        rvItens.setLayoutManager(layoutManager);

        rvItens.setAdapter(myAdapterL); //diz qual é o Adapter que vai construir os elementos da lista

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(rvItens.getContext(), DividerItemDecoration.VERTICAL);
        rvItens.addItemDecoration(dividerItemDecoration);


    }

    ImageListener imageListener = new ImageListener() {
        @Override
        public void setImageForPosition(int position, ImageView imageView) {
            imageView.setImageResource(sampleImages[position]);
        }
    };
}