package com.example.tripou2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.tripou2.Activity.Lugar;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapterL extends RecyclerView.Adapter{

    Lugar lugar;
    List<Comentario> comentarios;

    public MyAdapterL(Lugar lugar, List<Comentario> comentarios) { //construtor
        this.lugar = lugar;
        this.comentarios = comentarios;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(lugar);
        View v = inflater.inflate(R.layout.comentario, parent, false); // v guarda o layout construído
        return new MyViewHolder(v); //guarda o item gerado dentro de MyViewHolder
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Comentario comentario = comentarios.get(position);

        View v = holder.itemView;

        ImageView imvPhoto = v.findViewById(R.id.imageView2);
        imvPhoto.setImageResource(comentario.Photo);

        TextView tvNome = v.findViewById(R.id.textView13);
        tvNome.setText(comentario.Nome);

        TextView tvComentario = v.findViewById(R.id.textView14);
        tvComentario.setText(comentario.Comentario);

    }

    @Override
    public int getItemCount() { //serve para informar ao RecyclerView quantos itens existem na lista
        return comentarios.size();
    }
}
