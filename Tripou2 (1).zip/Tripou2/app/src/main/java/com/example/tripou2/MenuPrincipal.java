package com.example.tripou2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MenuPrincipal extends AppCompatActivity {
    static int NEW_ITEM_REQUEST = 1;


    MyAdapter myAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        FloatingActionButton btnRoteiro = findViewById(R.id.btnRoteiro); //pega o botão da interface
        btnRoteiro.setOnClickListener(new View.OnClickListener() { //quando o botão é clicado, executa a função a seguir:
            @Override
            public void onClick(View v) {
                Intent i = new Intent (MenuPrincipal.this, Roteiro.class); //cria uma intenção de "viajar" da página de MainActivity para a de NewItemActivity
                startActivity(i); //executa a intenção e espera um resultado
            }
        });

        FloatingActionButton btnAdicionarPonto = findViewById(R.id.btnAdicionarPonto); //pega o botão da interface
        btnAdicionarPonto.setOnClickListener(new View.OnClickListener() { //quando o botão é clicado, executa a função a seguir:
            @Override
            public void onClick(View v) {
                Intent i = new Intent (MenuPrincipal.this, CadastroPonto.class); //cria uma intenção de "viajar" da página de MainActivity para a de NewItemActivity
                startActivity(i); //executa a intenção e espera um resultado
            }
        });

        MenuPrincipalViewModel viewModel = new ViewModelProvider(this).get(MenuPrincipalViewModel.class);
        List<PontoTuristico> pontoTuristicos = viewModel.getItens();

        myAdapter = new MyAdapter(this, pontoTuristicos); //instância do MyAdapter

        //configurando RecyclerView:
        RecyclerView rvItens = findViewById(R.id.rvMenu);
        rvItens.setHasFixedSize(true); //diz que todos os itens da lista terão o mesmo tamanho

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);//diz de que forma os itens serão exibidos na lista, nesse cado, será de forma linear
        rvItens.setLayoutManager(layoutManager);

        rvItens.setAdapter(myAdapter); //diz qual é o Adapter que vai construir os elementos da lista

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(rvItens.getContext(), DividerItemDecoration.VERTICAL);
        rvItens.addItemDecoration(dividerItemDecoration);


    }
}