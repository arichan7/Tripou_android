package com.example.tripou2;

import java.util.ArrayList;
import java.util.List;

import androidx.lifecycle.ViewModel;

public class LugarViewModel extends ViewModel {
    List<Comentario> itensC = new ArrayList<>();

    public LugarViewModel() {

        Comentario c1 = new Comentario();
        c1.Photo = R.drawable.usuario;
        c1.Nome = "Thamiris";
        c1.Comentario = "Lindo!";

        Comentario c2 = new Comentario();
        c2.Photo = R.drawable.usuario;
        c2.Nome = "Pedro";
        c2.Comentario = "Lugar incrível!";

        Comentario c3 = new Comentario();
        c3.Photo = R.drawable.usuario;
        c3.Nome = "Cecilia";
        c3.Comentario = "Maravilhoso!";


        itensC.add(c1);
        itensC.add(c2);
        itensC.add(c3);
    }

    public List<Comentario> getItensC() {
        return itensC;
    }
}
