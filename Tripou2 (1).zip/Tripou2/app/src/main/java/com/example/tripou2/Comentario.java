package com.example.tripou2;

public class Comentario {
    public int Photo;
    public String Nome;
    public String Comentario;
    public int nEstrelas;
}
