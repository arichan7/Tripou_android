package com.example.tripou2;

public class PontoTuristico {
    public int Photo;
    public String Name;
    public int nEstrelas;
    public int tempoH;
    public int tempoM;
    public String description;
}
