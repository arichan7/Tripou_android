package com.example.tripou2;

import java.util.ArrayList;
import java.util.List;

import androidx.lifecycle.ViewModel;

public class MenuPrincipalViewModel extends ViewModel {
    List<PontoTuristico> itens = new ArrayList<>();

    public MenuPrincipalViewModel() {
        PontoTuristico item1 = new PontoTuristico();
        item1.Name = "Mosteiro Zen Budista";
        item1.Photo = R.drawable.buda;
        item1.nEstrelas = 5;

        PontoTuristico item2 = new PontoTuristico();
        item2.Name = "Parque do China";
        item2.Photo = R.drawable.china1;
        item2.nEstrelas = 1;

        PontoTuristico item3 = new PontoTuristico();
        item3.Name = "Convento da Penha";
        item3.Photo = R.drawable.penha1;
        item3.nEstrelas = 4;

        itens.add(item1);
        itens.add(item2);
        itens.add(item3);
    }

    public List<PontoTuristico> getItens() { return itens; }
}

