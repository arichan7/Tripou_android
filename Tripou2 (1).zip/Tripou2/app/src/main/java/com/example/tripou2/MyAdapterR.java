package com.example.tripou2;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.tripou2.Activity.Lugar;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapterR extends RecyclerView.Adapter {
    RoteiroPronto roteiroPronto;
    List<PontoTuristico> pontosTuristicos;

    public MyAdapterR(RoteiroPronto roteiroPronto, List<PontoTuristico> pontosTuristicos) { //construtor
        this.roteiroPronto = roteiroPronto;
        this.pontosTuristicos = pontosTuristicos;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { //cria as interfaces, mas sem preenchê-las (cria os elementos da lista)
        LayoutInflater inflater = LayoutInflater.from(roteiroPronto);
        View v = inflater.inflate(R.layout.roteiro_item, parent, false); // v guarda o layout construído
        return new MyViewHolder(v); //guarda o item gerado dentro de MyViewHolder
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) { //preenche os elementos de interface com os dados
        PontoTuristico pontoTuristico = pontosTuristicos.get(position);

        View v = holder.itemView;

        ImageView imvPhoto = v.findViewById(R.id.imageView3);
        imvPhoto.setImageResource(pontoTuristico.Photo);

        TextView tvNome = v.findViewById(R.id.textView4);
        tvNome.setText(pontoTuristico.Name);

        RatingBar ratingBar = v.findViewById(R.id.ratingBar4);
        ratingBar.setNumStars(pontoTuristico.nEstrelas);

        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(roteiroPronto, Lugar.class);
                roteiroPronto.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() { //serve para informar ao RecyclerView quantos itens existem na lista
        return pontosTuristicos.size();
    }
}


