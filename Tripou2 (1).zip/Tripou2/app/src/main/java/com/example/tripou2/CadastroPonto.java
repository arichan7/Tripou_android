package com.example.tripou2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class CadastroPonto extends AppCompatActivity {

    private Button bntImagem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_ponto);

        Button btnImagem = findViewById(R.id.bntImagem); //pega o botão da interface
        btnImagem.setOnClickListener(new View.OnClickListener() { //quando o botão é clicado, executa a função a seguir:
            @Override
            public void onClick(View v) {

            }
        });

    }


}