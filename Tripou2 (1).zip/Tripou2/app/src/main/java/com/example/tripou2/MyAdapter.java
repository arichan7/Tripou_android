package com.example.tripou2;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tripou2.Activity.Lugar;

public class MyAdapter extends RecyclerView.Adapter {
    MenuPrincipal menuPrincipal;
    List<PontoTuristico> pontosTuristicos;

    public MyAdapter(MenuPrincipal menuPrincipal, List<PontoTuristico> pontosTuristicos) { //construtor
        this.menuPrincipal = menuPrincipal;
        this.pontosTuristicos = pontosTuristicos;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { //cria as interfaces, mas sem preenchê-las (cria os elementos da lista)
        LayoutInflater inflater = LayoutInflater.from(menuPrincipal);
        View v = inflater.inflate(R.layout.roteiro_item, parent, false); // v guarda o layout construído
        return new MyViewHolder(v); //guarda o item gerado dentro de MyViewHolder
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) { //preenche os elementos de interface com os dados
        PontoTuristico pontoTuristico = pontosTuristicos.get(position);

        View v = holder.itemView;

        ImageView imvPhoto = v.findViewById(R.id.imageView3);
        imvPhoto.setImageResource(pontoTuristico.Photo);

        TextView tvNome = v.findViewById(R.id.textView4);
        tvNome.setText(pontoTuristico.Name);

        RatingBar ratingBar = v.findViewById(R.id.ratingBar4);
        ratingBar.setNumStars(pontoTuristico.nEstrelas);

        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(menuPrincipal, Lugar.class);
                menuPrincipal.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() { //serve para informar ao RecyclerView quantos itens existem na lista
        return pontosTuristicos.size();
    }
}

